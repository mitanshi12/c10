var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["7535d542-1977-4413-9e15-e9feb800b66d","644cb607-7973-4362-9e05-d0c7569a03c0","6241c46c-3442-4540-a194-6dde248df567","ab6f4581-e66f-48a2-b7f3-d95dd63ddf9a","333f845d-8908-4c45-ad5e-31c030880887","0cc9b1ac-4a29-4add-9b79-165266251bc6","ebd702c2-f7bc-4059-9ead-90dc1f1f7e41"],"propsByKey":{"7535d542-1977-4413-9e15-e9feb800b66d":{"name":"fish","sourceUrl":null,"frameSize":{"x":400,"y":400},"frameCount":1,"looping":false,"frameDelay":12,"version":"vCSvXtrK_5y5rLCRgewccNwgt5WTKbGJ","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/7535d542-1977-4413-9e15-e9feb800b66d.png"},"644cb607-7973-4362-9e05-d0c7569a03c0":{"name":"creature1","sourceUrl":"assets/api/v1/animation-library/gamelab/zH1WSj3ukBEBbatiuMBpuxn_.oiNUOym/category_animals/creature_03.png","frameSize":{"x":394,"y":371},"frameCount":1,"looping":true,"frameDelay":5,"version":"zH1WSj3ukBEBbatiuMBpuxn_.oiNUOym","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":394,"y":371},"rootRelativePath":"assets/api/v1/animation-library/gamelab/zH1WSj3ukBEBbatiuMBpuxn_.oiNUOym/category_animals/creature_03.png"},"6241c46c-3442-4540-a194-6dde248df567":{"name":"creature2","sourceUrl":"assets/api/v1/animation-library/gamelab/uKV_jB5Pm4ExAlUVHhzQQCeK.vyxluGA/category_animals/creature_14.png","frameSize":{"x":396,"y":256},"frameCount":1,"looping":true,"frameDelay":5,"version":"uKV_jB5Pm4ExAlUVHhzQQCeK.vyxluGA","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":396,"y":256},"rootRelativePath":"assets/api/v1/animation-library/gamelab/uKV_jB5Pm4ExAlUVHhzQQCeK.vyxluGA/category_animals/creature_14.png"},"ab6f4581-e66f-48a2-b7f3-d95dd63ddf9a":{"name":"crocodile_1","sourceUrl":"assets/api/v1/animation-library/gamelab/.OgILExIWH7zPE7eYiSHTuP5MvAT96YL/category_animals/crocodile.png","frameSize":{"x":390,"y":150},"frameCount":1,"looping":true,"frameDelay":5,"version":".OgILExIWH7zPE7eYiSHTuP5MvAT96YL","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":150},"rootRelativePath":"assets/api/v1/animation-library/gamelab/.OgILExIWH7zPE7eYiSHTuP5MvAT96YL/category_animals/crocodile.png"},"333f845d-8908-4c45-ad5e-31c030880887":{"name":"virus03_03_1","sourceUrl":"assets/api/v1/animation-library/gamelab/KoZz0QksHdpzqfX71bq5vgJR__O0e4sP/category_germs/virus03_03.png","frameSize":{"x":388,"y":390},"frameCount":1,"looping":true,"frameDelay":5,"version":"KoZz0QksHdpzqfX71bq5vgJR__O0e4sP","categories":["germs"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":388,"y":390},"rootRelativePath":"assets/api/v1/animation-library/gamelab/KoZz0QksHdpzqfX71bq5vgJR__O0e4sP/category_germs/virus03_03.png"},"0cc9b1ac-4a29-4add-9b79-165266251bc6":{"name":"background_underwater_11_2","sourceUrl":null,"frameSize":{"x":400,"y":399},"frameCount":2,"looping":true,"frameDelay":12,"version":"QWJ.oVVaQR2DsRdu2Lsfl9tKWv8444NE","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":798},"rootRelativePath":"assets/0cc9b1ac-4a29-4add-9b79-165266251bc6.png"},"ebd702c2-f7bc-4059-9ead-90dc1f1f7e41":{"name":"animalhead_bison_1","sourceUrl":null,"frameSize":{"x":400,"y":398},"frameCount":2,"looping":true,"frameDelay":12,"version":"xiZUM1WVKfg_1uxWrYLWZ1ag27FeXLMm","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":796},"rootRelativePath":"assets/ebd702c2-f7bc-4059-9ead-90dc1f1f7e41.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var life=0;
var creature1,creature2, creature3, creature4;
var boundary1, boundary2;
var fish



boundary1=createSprite(200,50,420,10);
 boundary2=createSprite(200,350,410,10);
 
 fish=createSprite(23,179,10,10);
 fish.shapeColor= "fish";
 fish.setAnimation("fish");
 fish.scale = 0.10; 
 
 
 creature1=createSprite(100,130,10,10);
 creature1.shapeColor="blue";
 creature2=createSprite(215,130,10,10);
 creature2.shapeColor="blue";
 creature3=createSprite(165,250,10,10);
 creature3.shapeColor="blue";
 creature4=createSprite(270,250,10,10);
 creature4.shapeColor="blue";
 
 
 creature1.velocityY=6;
 creature2.velocityY=6;

 creature3.velocityY=6;
 creature4.velocityY=6;


creature1.setAnimation("creature1");
creature2.setAnimation("creature1");
creature3.setAnimation("creature2");
creature4.setAnimation("creature2");


creature1.scale = 0.1;
creature2.scale = 0.1;
creature3.scale = 0.1;
creature4.scale = 0.1;


function draw() {
  background("underwater_11_1");
  text("LIVES:"+ life,200,100);
  strokeWeight(5);
  rect(0,100,20,190);
  fill("pink");
  rect(380,100,190,190);
  

  
  creature1.bounceOff(boundary1);
  creature1.bounceOff(boundary2);
  creature2.bounceOff(boundary1);
  creature2.bounceOff(boundary2);
  creature3.bounceOff(boundary1);
  creature3.bounceOff(boundary2);
  creature4.bounceOff(boundary1);
  creature4.bounceOff(boundary2);
  
//add the condition to make the fish left and right, up and down
if (keyDown("left")){
fish.x=fish.x -3;
}


if (keyDown("right")) {
  fish.x=fish.x +5;
}

if (keyDown ("up")){
   fish.y = fish.y-5; 
}

if (keyDown ("down")){
   fish.y =fish.y+5;
}


if(fish.isTouching(creature1)|| fish.isTouching(creature2)|| fish.isTouching(creature3)|| fish.isTouching(creature4)){
  playSound("assets/category_achievements/bubbly_game_achievement_sound.mp3")
  fish.x=200;
  fish.y=350;
var death = death -5;
}

if(fish.isTouching(creature1)){
playSound(12);sound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3")
  fish.x=200;
  fish.y=345;
var goal=goal+1;
} 

//add the condition to reduce the life of fish if it touch the creature.
if (fish.isTouching(creature1)|| fish.isTouching(creature2)||fish.isTouching(creature3)||fish.isTouching(creature4)){  
 fish.x=20; 
 fish.y=190;
 life=life +1;
 }
 drawSprites()   
}
  
  
  
  
  
  
  
  
  

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
